# BSP-Types

State: Working, Unstable, feature releases might break 0.1

Collection of Build Protocol types as defined in
[specification](https://build-server-protocol.github.io/docs/specification.html). There are
might be slight renaming for convenience so don't expect one-to-one mapping of interface names.
