Deprecated. Use the [com](https://github.com/microsoft/com-rs) crate instead.
