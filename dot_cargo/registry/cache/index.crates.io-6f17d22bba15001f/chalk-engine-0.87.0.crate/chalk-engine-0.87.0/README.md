The core crate for Chalk.

See [Github](https://github.com/rust-lang/chalk) for up-to-date information.
