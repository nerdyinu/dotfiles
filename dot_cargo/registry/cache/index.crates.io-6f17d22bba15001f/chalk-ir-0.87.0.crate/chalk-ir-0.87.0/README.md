A rust type library for chalk.

See [Github](https://github.com/rust-lang/chalk) for up-to-date information.
