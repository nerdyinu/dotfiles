Version 1.0.3 (2018-09-18)
==========================

Misc
----

- Changed the default `parse` function to use a static parser

Version 1.0.2 (2018-08-14)
==========================

Misc
----

- Add tests for WASM

Version 1.0.1 (2018-08-11)
==========================

Bugfixes
--------

- Fixed an issue with "GMT+3" not being handled correctly

Misc
----

- Upgrade `lazy_static` and `rust_decimal` dependencies

Version 1.0.0 (2018-08-03)
==========================

Initial release. Passes all relevant unit tests from Python's
`dateutil` project.
