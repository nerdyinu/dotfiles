//! Listen and react to time.
pub use iced_core::time::{Duration, Instant};

pub use iced_futures::backend::default::time::*;
