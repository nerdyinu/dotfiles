//! Listen and react to touch events.
pub use crate::core::touch::{Event, Finger};
