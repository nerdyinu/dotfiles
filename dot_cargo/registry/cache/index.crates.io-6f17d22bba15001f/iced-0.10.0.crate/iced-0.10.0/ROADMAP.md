# Roadmap
We have [a detailed graphical roadmap now](https://whimsical.com/roadmap-iced-7vhq6R35Lp3TmYH4WeYwLM)!

Before diving into the roadmap, check out [the ecosystem overview] to get an idea of the current state of the library.

[the ecosystem overview]: ECOSYSTEM.md
