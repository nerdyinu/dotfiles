A helper crate for use by chalk crates for `derive` macros.

See [Github](https://github.com/rust-lang/chalk) for up-to-date information.
