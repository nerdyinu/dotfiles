0.2.1 / 2016-12-04
=================

* Add VcardParser (vcard): Take a buffer and structure the content into components.
* Line Parser is officialy working with vcard format.
* Add some basic tests on LineReader (vcard).
* Add some basic tests on LineParser (vcard).
* Add conditionnal compilation.

0.2.0 / 2016-12-03
=================

* Add LineReader (ical/vcard): Take a buffer and unfold the content.
* Add LineParser (ical/vcard): Take a buffer or LineReader and parse the content. *Have not been officialy tested with vcard format!*
* Add IcalParser (ical): Take a buffer and structure the content into components.
* Add some basic tests on LineReader.
* Add some basic tests on LineParser.
* Add some documentation.


0.1.0 / 2016-11-23 - Yanked
=================

* Try version... Nothing to see here...
