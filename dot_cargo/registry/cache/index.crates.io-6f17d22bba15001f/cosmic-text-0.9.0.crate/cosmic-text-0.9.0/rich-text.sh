RUST_LOG=cosmic_text=debug,rich_text=debug cargo run --release --package rich-text -- "$@"
