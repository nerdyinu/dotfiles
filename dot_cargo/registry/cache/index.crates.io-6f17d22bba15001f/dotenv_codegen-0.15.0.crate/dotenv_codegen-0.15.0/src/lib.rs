use proc_macro_hack::proc_macro_hack;

#[proc_macro_hack]
pub use dotenv_codegen_implementation::dotenv;