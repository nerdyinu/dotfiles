// TODO: untracked file detection, needs fs::Cache
