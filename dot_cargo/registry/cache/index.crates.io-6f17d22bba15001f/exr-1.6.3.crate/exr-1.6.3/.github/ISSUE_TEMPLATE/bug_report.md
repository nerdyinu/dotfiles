---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

# Description
What happened?

# Reproducing
How can we reproduce the behaviour? Embed code snippets and problematic EXR files.

# Environment
- Operating System
- CPU Model (Big Endian or Little Endian?)
- EXRS Version used
