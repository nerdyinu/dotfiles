## Raytracing

A good showcase of Metal 3 raytracing features. 

![Screenshot of the final render](./screenshot.png)

## To Run

```
cargo run --example raytracing
```
