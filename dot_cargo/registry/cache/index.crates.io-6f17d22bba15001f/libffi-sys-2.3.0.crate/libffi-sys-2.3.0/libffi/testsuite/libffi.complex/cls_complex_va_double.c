/* Area:	ffi_call, closure_call
   Purpose:	Test complex' passed in variable argument lists.
   Limitations:	none.
   PR:		none.
   Originator:	<vogt@linux.vnet.ibm.com>.  */

/* { dg-do run } */

#include "complex_defs_double.inc"
#include "cls_complex_va.inc"
