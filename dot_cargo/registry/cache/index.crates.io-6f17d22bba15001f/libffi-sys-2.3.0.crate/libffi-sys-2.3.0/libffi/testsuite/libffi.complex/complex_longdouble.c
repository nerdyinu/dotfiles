/* Area:	ffi_call
   Purpose:	Check complex types.
   Limitations:	none.
   PR:		none.
   Originator:	<vogt@linux.vnet.ibm.com>.  */

/* { dg-do run } */

#include "complex_defs_longdouble.inc"
#include "complex.inc"
