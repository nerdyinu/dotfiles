This directory records design decisions, in the [ADR style](https://adr.github.io/).
