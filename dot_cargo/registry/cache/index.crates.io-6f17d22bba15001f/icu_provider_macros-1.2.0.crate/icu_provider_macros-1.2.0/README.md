# icu_provider_macros [![crates.io](https://img.shields.io/crates/v/icu_provider_macros)](https://crates.io/crates/icu_provider_macros)

Proc macros for the ICU4X data provider.

These macros are re-exported from `icu_provider`.

## More Information

For more information on development, authorship, contributing etc. please visit [`ICU4X home page`](https://github.com/unicode-org/icu4x).
