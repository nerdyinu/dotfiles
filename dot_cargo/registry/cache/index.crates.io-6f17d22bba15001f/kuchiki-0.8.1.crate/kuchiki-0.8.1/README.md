Kuchiki (朽木)
==============

HTML/XML¹ tree manipulation library for Rust.

[Documentation](https://docs.rs/kuchiki/)

See [users.rust-lang.org discussion](http://users.rust-lang.org/t/kuchiki-a-vaporware-html-xml-tree-manipulation-library/435).

¹ There is no support for XML syntax yet. The plan is to integrate with an existing parser.
