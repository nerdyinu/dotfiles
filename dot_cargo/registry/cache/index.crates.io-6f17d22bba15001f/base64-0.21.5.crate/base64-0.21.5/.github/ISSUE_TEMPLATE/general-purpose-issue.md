---
name: General purpose issue
about: General purpose issue
title: Default issue
labels: ''
assignees: ''

---

# Before you file an issue

- Did you read the docs?
- Did you read the README?

# The problem

- 

# How I, the issue filer, am going to help solve it

-
