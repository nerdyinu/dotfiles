#ifndef TEST_CPU_FEATURES_H
#define TEST_CPU_FEATURES_H

#include "cpu_features.h"

extern struct cpu_features test_cpu_features;

#endif
