# Changes

## Unreleased - 2022-xx-xx


## 0.1.3 - 2022-05-03
- Minimum supported Rust version (MSRV) is now 1.49.


## 0.1.2 - 2021-12-18
- Fix crate metadata.


## 0.1.1 - 2021-03-29
- Move `LocalWaker` to it's own crate.
