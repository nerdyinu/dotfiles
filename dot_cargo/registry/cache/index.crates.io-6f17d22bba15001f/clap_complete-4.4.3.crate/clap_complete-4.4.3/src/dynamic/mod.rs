//! Complete commands within shells

mod completer;

pub mod shells;

pub use completer::*;
