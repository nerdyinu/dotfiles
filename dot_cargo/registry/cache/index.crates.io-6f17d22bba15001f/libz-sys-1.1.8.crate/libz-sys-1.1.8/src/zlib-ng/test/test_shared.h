static const char hello[] = "hello, hello!";
static const int hello_len = sizeof(hello);
