pub struct Thing;

inventory::submit!(Thing);

fn main() {}
