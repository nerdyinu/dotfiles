mod app;

use app::App;

fn main() {
    sycamore::render(App);
}