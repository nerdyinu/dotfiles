import { render } from "preact";
import App from "./App";
import "./styles.css";

render(<App />, document.getElementById("root"));
