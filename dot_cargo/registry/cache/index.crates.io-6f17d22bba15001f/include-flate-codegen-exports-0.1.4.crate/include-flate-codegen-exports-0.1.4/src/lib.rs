#[cfg_attr(feature = "stable", proc_macro_hack::proc_macro_hack)]
pub use include_flate_codegen::deflate_file;

#[cfg_attr(feature = "stable", proc_macro_hack::proc_macro_hack)]
pub use include_flate_codegen::deflate_utf8_file;
