# Changelog

## 0.18.0 - 2023-04-02
[0.17.0...0.18.0](https://github.com/rust-lang/git2-rs/compare/git2-curl-0.17.0...git2-curl-0.18.0)

- Updated to [git2 0.17.0](../CHANGELOG.md#0170---2023-04-02)

## 0.17.0 - 2023-01-10
[0.16.0...0.17.0](https://github.com/rust-lang/git2-rs/compare/git2-curl-0.16.0...git2-curl-0.17.0)

- Updated to [git2 0.16.0](../CHANGELOG.md#0160---2023-01-10)

## 0.16.0 - 2022-07-28
[0.15.0...0.16.0](https://github.com/rust-lang/git2-rs/compare/git2-curl-0.15.0...git2-curl-0.16.0)

- Updated to [git2 0.15.0](../CHANGELOG.md#0150---2022-07-28)

## 0.15.0 - 2022-02-28
[0.14.1...0.15.0](https://github.com/rust-lang/git2-rs/compare/git2-curl-0.14.1...git2-curl-0.15.0)

- Updated to [git2 0.14.0](../CHANGELOG.md#0140---2022-02-24)
