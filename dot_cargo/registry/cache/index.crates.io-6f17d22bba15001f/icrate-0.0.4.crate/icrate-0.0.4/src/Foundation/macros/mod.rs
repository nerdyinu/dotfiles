mod ns_string;
