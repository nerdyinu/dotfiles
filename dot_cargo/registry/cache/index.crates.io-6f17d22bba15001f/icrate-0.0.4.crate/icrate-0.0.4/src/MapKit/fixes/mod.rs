#[cfg(feature = "MapKit_MKMapItem")]
unsafe impl crate::Foundation::NSCoding for crate::MapKit::MKMapItem {}
