use std::os::raw::c_double;

pub type CFTimeInterval = c_double;
