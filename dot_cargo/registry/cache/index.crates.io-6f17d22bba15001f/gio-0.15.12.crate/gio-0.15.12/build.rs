// This whole build.rs file is required because of the `OUT_DIR` environment variable
// provided by cargo when a build file is present.
fn main() {}
