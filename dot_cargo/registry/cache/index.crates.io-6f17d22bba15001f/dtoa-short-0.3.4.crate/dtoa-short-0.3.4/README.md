# dtoa-short

[![Latest Version](https://img.shields.io/crates/v/dtoa-short.svg)](https://crates.io/crates/dtoa-short)
[![Build Status](https://travis-ci.org/upsuper/dtoa-short.svg?branch=master)](https://travis-ci.org/upsuper/dtoa-short)
[![codecov](https://codecov.io/gh/upsuper/dtoa-short/branch/master/graph/badge.svg)](https://codecov.io/gh/upsuper/dtoa-short)
