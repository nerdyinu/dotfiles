exports.is_temporal_supported = function () {
    return typeof Temporal === 'object';
};
