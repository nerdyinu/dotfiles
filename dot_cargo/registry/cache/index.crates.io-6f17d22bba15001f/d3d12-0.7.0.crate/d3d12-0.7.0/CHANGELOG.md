# Change Log

## v0.6.0 (2023-01-25)
  - add helpers for IDXGIFactoryMedia
  - add `create_swapchain_for_composition_surface_handle`

## v0.5.0 (2022-07-01)
  - add COM helpers
  - enable D3D11 adapter use

## v0.4.1 (2021-08-18)
  - expose all indirect argument types
  - expose methods for setting root constants

## v0.4.0 (2021-04-29)
  - update `libloading` to 0.7

## v0.3.1 (2020-07-07)
  - create shader from IL
  - fix default doc target
  - debug impl for root descriptors

## v0.3.0 (2019-11-01)
  - resource transitions
  - dynamic library loading

## v0.2.2 (2019-10-04)
  - add `D3DHeap`
  - add root descriptor

## v0.1.0 (2018-12-26)
  - basic version
