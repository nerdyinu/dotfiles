# kqueue-sys

Low-level `kqueue(2)` ffi layer for `kqueue` crate
