//! Backends that are only available on Wasm targets.
pub mod wasm_bindgen;
