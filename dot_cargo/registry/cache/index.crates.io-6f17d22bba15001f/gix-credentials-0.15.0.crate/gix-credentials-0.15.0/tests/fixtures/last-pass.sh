#!/bin/bash
set -eu

echo username=user
echo password=pass
echo quit=1
