#!/bin/bash

echo protocol=ftp
echo host=github.com
echo path=byron/gitoxide
echo url=http://example.com:8080/path/to/git/

