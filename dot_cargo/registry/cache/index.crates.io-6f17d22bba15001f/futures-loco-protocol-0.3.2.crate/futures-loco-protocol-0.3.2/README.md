[![Crates.io](https://img.shields.io/crates/v/futures-loco-protocol)](https://crates.io/crates/futures-loco-protocol/)
[![docs.rs](https://img.shields.io/docsrs/futures-loco-protocol)](https://docs.rs/futures-loco-protocol/latest/)

# `futures-loco-protocol`
Asynchronous loco client, loco session, secure stream for `futures` using `loco-protocol`

## License
MIT
