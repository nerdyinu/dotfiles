# brownstone
A library for safely constructing statically sized arrays
