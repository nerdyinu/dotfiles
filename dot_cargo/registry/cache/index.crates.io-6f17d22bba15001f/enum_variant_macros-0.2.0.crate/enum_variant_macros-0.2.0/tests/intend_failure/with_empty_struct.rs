use enum_variant_macros::*;
#[derive(FromVariants)]
struct NotEnum;
fn main() {
}
