use enum_variant_macros::*;
#[derive(FromVariants)]
struct John {
	num: i32,
	red: i32,
}
fn main() {
}
