# Summary formatting tests

- [*Italic* `code` \*escape\* \`escape2\`](formatted-summary.md)
- [Soft
line break](soft.md)
- [\<escaped tag\>](escaped-tag.md)
