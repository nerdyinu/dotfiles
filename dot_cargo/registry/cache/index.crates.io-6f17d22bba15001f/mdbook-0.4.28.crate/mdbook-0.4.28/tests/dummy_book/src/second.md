# Second Chapter

This makes sure you can insert runnable Rust files.

{{#playground example.rs}}
