#[actix_rt::test]
fn my_test() {
    futures_util::future::ready(()).await
}

fn main() {}
