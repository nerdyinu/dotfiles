# Corcovado

Corcovado is a maintained fork of mio 0.6.x along mio-signal-hook, mio-extras and using Windows API that works in Windows 11. It uses Rust edition 2021 instead of 2018.

Corcovado also uses Rust standard library for net and io instead of Mio 0.6.x.