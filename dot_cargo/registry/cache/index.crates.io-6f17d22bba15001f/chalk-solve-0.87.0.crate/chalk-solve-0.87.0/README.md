A library that defines the rules that translates Rust IR to logical predicates.

See [Github](https://github.com/rust-lang/chalk) for up-to-date information.
