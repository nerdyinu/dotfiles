mod write_tuple;

pub use self::write_tuple::WriteTuple;
