# is_debug 
The crate by Rust that get build model is debug.

### use function
```TOML
[dependencies]
is_debug = "1"
```

```rust
fn main() {
    println!(is_debug());
    
    println!(is_release());
}
```
