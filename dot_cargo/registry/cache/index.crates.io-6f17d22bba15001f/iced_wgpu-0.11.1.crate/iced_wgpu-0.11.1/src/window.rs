//! Display rendering results on windows.
pub mod compositor;

pub use compositor::Compositor;
pub use wgpu::Surface;
