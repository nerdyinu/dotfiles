Please see <https://docs.rs/io-close>.
