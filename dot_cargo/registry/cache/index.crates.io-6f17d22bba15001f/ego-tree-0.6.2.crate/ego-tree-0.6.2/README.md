# Ego Tree

[![Crate version][crate-badge]][crate]
[![Build status][travis-badge]][travis]

[crate]: https://crates.io/crates/ego-tree
[travis]: https://travis-ci.org/programble/ego-tree
[crate-badge]: https://img.shields.io/crates/v/ego-tree.svg
[travis-badge]: https://img.shields.io/travis/programble/ego-tree.svg

Vec-backed ID-tree.
