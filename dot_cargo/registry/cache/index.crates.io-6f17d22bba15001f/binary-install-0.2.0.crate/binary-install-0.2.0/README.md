# `binary-install`

Install a binary from a path to a global cache.

[![Build Status](https://github.com/rustwasm/binary-install/actions/workflows/test.yml/badge.svg?branch=master)](https://github.com/rustwasm/binary-install/actions/workflows/test.yml)
[![crates.io](https://meritbadge.herokuapp.com/binary-install)](https://crates.io/crates/binary-install)
[![API Documentation on docs.rs](https://docs.rs/binary-install/badge.svg)](https://docs.rs/binary-install)

