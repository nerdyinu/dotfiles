# `sval_dynamic`

[![Rust](https://github.com/sval-rs/sval/workflows/dynamic/badge.svg)](https://github.com/sval-rs/sval/actions)
[![Latest version](https://img.shields.io/crates/v/sval.svg)](https://crates.io/crates/sval_dynamic)
[![Documentation Latest](https://docs.rs/sval_dynamic/badge.svg)](https://docs.rs/sval_dynamic)

Object-safe versions of `sval::Stream` and `sval::Value`.
