# `sval_ref`

[![Rust](https://github.com/sval-rs/sval/workflows/ref/badge.svg)](https://github.com/sval-rs/sval/actions)
[![Latest version](https://img.shields.io/crates/v/sval.svg)](https://crates.io/crates/sval_ref)
[![Documentation Latest](https://docs.rs/sval_ref/badge.svg)](https://docs.rs/sval_ref)

A variant of `sval::Value` for types with internal references.
