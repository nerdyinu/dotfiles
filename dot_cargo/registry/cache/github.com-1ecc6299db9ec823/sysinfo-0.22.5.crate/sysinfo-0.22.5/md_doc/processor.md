Struct containing information of a processor.
