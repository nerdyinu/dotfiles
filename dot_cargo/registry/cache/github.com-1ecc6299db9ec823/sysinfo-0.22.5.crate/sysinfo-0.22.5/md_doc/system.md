Structs containing system's information.
