These represent an old log of benchmarks from regex 1.7.3 and older. New
and much more comprehensive benchmarks are now maintained as part of the
[rebar] project.

We keep these old benchmark recordings for posterity, but they may be removed
in the future.

Measurements can be compared using the [`cargo-benchcmp`][cargo-benchcmp] tool.

[rebar]: https://github.com/BurntSushi/rebar
[cargo-benchcmp]: https://github.com/BurntSushi/cargo-benchcmp
