Extra completion files that get appended to the
clap output, in order to support dynamic commands.
