# Assets for the Utils Crate

Here reside assets, that are especially needed for
setup eg. a default configuration file.
