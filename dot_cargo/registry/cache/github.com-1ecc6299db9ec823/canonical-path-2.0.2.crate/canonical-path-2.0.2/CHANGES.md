## [2.0.2] (2019-05-24)

- Test all crates on Rust 1.35.0 ([#206])

## [2.0.1] (2019-05-22)

- Canonicalize `current_exe()` ([#198])

## [2.0.0] (2019-05-20)

- Clean up and modernize ([#193])
- Update to 2018 edition ([#138])

## 1.0.0 (2018-10-03)

- Initial 1.0 release

## 0.1.1 (2018-04-09)

- Fix link to CircleCI badge in `Cargo.toml`

## 0.1.0 (2018-04-09)

- Initial release

[2.0.2]: https://github.com/iqlusioninc/crates/pull/207
[#206]: https://github.com/iqlusioninc/crates/pull/206
[2.0.1]: https://github.com/iqlusioninc/crates/pull/199
[#198]: https://github.com/iqlusioninc/crates/pull/198
[2.0.0]: https://github.com/iqlusioninc/crates/pull/194
[#193]: https://github.com/iqlusioninc/crates/pull/193
[#138]: https://github.com/iqlusioninc/crates/pull/138
