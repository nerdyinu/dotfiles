include!("../../example_main.rs");
tokio_main!(windows, feature = "tokio_support");
