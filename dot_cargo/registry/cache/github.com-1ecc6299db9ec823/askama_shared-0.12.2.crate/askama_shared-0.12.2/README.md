# askama_shared: shared code for the Askama templating engine

[![Documentation](https://docs.rs/askama_shared/badge.svg)](https://docs.rs/askama_shared/)
[![Latest version](https://img.shields.io/crates/v/askama_shared.svg)](https://crates.io/crates/askama_shared)
[![Build Status](https://github.com/djc/askama/workflows/CI/badge.svg)](https://github.com/djc/askama/actions?query=workflow%3ACI)
[![Chat](https://badges.gitter.im/gitterHQ/gitter.svg)](https://gitter.im/djc/askama)

This crate contains helper code used by the [Askama](https://github.com/djc/askama)
templating engine.
