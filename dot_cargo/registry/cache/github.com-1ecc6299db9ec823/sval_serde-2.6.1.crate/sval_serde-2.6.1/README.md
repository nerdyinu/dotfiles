# `sval_serde`

[![Rust](https://github.com/sval-rs/sval/workflows/serde/badge.svg)](https://github.com/sval-rs/sval/actions)
[![Latest version](https://img.shields.io/crates/v/sval.svg)](https://crates.io/crates/sval_serde)
[![Documentation Latest](https://docs.rs/sval_serde/badge.svg)](https://docs.rs/sval_serde)

Integration between `sval` and `serde`.
