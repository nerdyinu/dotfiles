# Changes

## [0.1.2] - 2019-07-18

### Added

* Add unix domnain sockets support


## [0.1.1] - 2019-04-16

### Added

* `IoStream` trait and impls for TcpStream, SslStream and TlsStream
