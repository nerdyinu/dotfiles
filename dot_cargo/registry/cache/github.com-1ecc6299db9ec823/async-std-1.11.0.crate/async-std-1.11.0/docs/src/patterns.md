# Patterns

This section documents small, useful patterns.

It is intended to be read at a glance, allowing you to get back when you have a problem.