pub use gix_testtools::Result;

mod normalize;
mod parse;
mod search;
