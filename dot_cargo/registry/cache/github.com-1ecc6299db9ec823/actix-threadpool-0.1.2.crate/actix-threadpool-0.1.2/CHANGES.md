# Changes

## [0.1.2] - 2019-08-05

### Changed

* Update `derive_more` to 0.15

* Update `parking_lot` to 0.9

## [0.1.1] - 2019-06-05

* Update parking_lot

## [0.1.0] - 2019-03-28

* Move threadpool to separate crate
