# Changelog

## \[0.1.0]

- Initial release.
  - [c3c4f51](https://github.com/tauri-apps/rust-icns/commit/c3c4f514e2a07a97c37c36c128a0cae4f9abe40e) feat: prepare for release on 2022-08-23
