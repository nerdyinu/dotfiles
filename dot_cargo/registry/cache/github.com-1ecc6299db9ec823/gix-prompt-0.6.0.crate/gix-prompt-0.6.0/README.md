
### Acknowledgements

Portions of this crate are  loosely based on [`rpassword`](https://github.com/conradkleinespel/duck).
