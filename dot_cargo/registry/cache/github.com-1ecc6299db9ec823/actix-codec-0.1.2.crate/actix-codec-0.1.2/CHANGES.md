# Changes

## [0.1.2] - 2019-03-27

* Added `Framed::map_io()` method.


## [0.1.1] - 2019-03-06

* Added `FramedParts::with_read_buffer()` method.


## [0.1.0] - 2018-12-09

* Move codec to separate crate
