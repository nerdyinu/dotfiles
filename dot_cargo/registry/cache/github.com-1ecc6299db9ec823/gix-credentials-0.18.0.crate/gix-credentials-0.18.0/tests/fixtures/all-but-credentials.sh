#!/bin/bash

echo protocol=ftp
echo host=example.com:8080
echo path=/path/to/git/

