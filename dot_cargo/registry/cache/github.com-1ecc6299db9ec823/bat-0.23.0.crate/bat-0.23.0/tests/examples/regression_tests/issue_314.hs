module Main where

main :: IO ()
main = putStrLn "Please show my file :c"
