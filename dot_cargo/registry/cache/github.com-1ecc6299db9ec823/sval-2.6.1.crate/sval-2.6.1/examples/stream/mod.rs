/*!
This file structure is here just so we can share this stream with multiple examples.
*/

pub mod simple;
