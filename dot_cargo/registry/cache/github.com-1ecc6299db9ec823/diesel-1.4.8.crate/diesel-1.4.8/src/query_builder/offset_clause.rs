simple_clause!(NoOffsetClause, OffsetClause, " OFFSET ");
