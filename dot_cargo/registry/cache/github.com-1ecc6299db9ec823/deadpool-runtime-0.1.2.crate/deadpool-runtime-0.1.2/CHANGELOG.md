## v0.1.2

* Fix links to tokio and async-std in documentation

## v0.1.1

* Fix tokio feature dependencies

## v0.1.0

* First release
