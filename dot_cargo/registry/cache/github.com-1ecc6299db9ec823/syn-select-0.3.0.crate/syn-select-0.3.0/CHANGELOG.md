v 0.3.0 (May 22, 2023)
* Update syn to v2

# v0.2.1 (June 15, 2022)
* Make syn_select::Selector implement Send and Sync (#9) 

# v0.2.0 (August 23, 2019)
* Update to `syn` 1.0.0 [#8](https://github.com/TedDriggs/syn-select/pull/8)

# v0.1.4 (February 11, 2019)
* Change `Debug` and `Display` impls for Selector [#5](https://github.com/TedDriggs/issues/5)

# v0.1.3 (February 4, 2019)
* Add single-term wildcard support [#1](https://github.com/TedDriggs/syn-select/issues/1)

# v0.1.2 (January 30, 2019)
* Expose `syn::Selector`
* Improve error messages

# v0.1.1 (January 29, 2019)
* Add changelog
* Update crate metadata to include examples