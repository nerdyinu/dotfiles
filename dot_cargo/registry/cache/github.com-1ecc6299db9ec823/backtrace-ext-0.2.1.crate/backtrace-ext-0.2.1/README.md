# backtrace-ext

[![crates.io](https://img.shields.io/crates/v/backtrace-ext.svg)](https://crates.io/crates/backtrace-ext)
[![docs](https://docs.rs/backtrace-ext/badge.svg)](https://docs.rs/backtrace-ext)
[![Rust CI](https://github.com/gankra/backtrace-ext/workflows/Rust%20CI/badge.svg?branch=main)](https://github.com/gankra/backtrace-ext/actions/workflows/ci.yml)

Minor conveniences on top of the backtrace crate, because I don't want to copy-paste this everywhere
I override a panic handler.