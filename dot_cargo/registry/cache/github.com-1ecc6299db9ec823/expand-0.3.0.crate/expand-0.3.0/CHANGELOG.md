# Changelog

## v0.3.0 - 2023-03-18

### Features
- Upgrade to syn 2

### Fixes
- Fix CI badge

## v0.2.1 - 2022-10-21

### Features
- remove direct dedpendency on proc-macro2


## v0.2.0 - 2020-11-06

### Features
- `expand` now also expands string literals


## v0.1.3 - 2020-11-03

### Features
- Improve error messages


## v0.1.2 - 2020-10-25

### Features
- Allow non byte string tokens after `@`


## v0.1.1 - 2020-10-24

### Features
- No_std support


## v0.1.0 - 2020-10-23

### Features
- `expand` macro to expand byte string literals
