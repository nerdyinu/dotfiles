# Change Log

## v0.1.4 (24-06-2019)
  - `BoxHelper`: replaced nullable pointer with NonNull

## v0.1.3 (31-05-2019)
  - fixed zero-sized box allocations
  - fixed file permissions in the package

## v0.1.2 (19-03-2019)
  - fixed box alignment

## v0.1.1 (15-03-2019)
  - `BoxHelper` extension

## v0.1 (15-03-2019)
  - `VecHelper` extension
