# `sval_buffer`

[![Rust](https://github.com/sval-rs/sval/workflows/buffer/badge.svg)](https://github.com/sval-rs/sval/actions)
[![Latest version](https://img.shields.io/crates/v/sval.svg)](https://crates.io/crates/sval_buffer)
[![Documentation Latest](https://docs.rs/sval_buffer/badge.svg)](https://docs.rs/sval_buffer)

Support for buffering implementations of `sval::Value`.
