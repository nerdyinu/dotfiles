# `sval_fmt`

[![Rust](https://github.com/sval-rs/sval/workflows/fmt/badge.svg)](https://github.com/sval-rs/sval/actions)
[![Latest version](https://img.shields.io/crates/v/sval.svg)](https://crates.io/crates/sval_fmt)
[![Documentation Latest](https://docs.rs/sval_fmt/badge.svg)](https://docs.rs/sval_fmt)

Format implementations of `sval::Value` using the `std::fmt` infrastructure.
