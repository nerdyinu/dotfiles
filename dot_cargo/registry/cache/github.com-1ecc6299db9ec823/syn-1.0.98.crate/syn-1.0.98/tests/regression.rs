#![allow(clippy::let_underscore_drop)]

mod regression {
    automod::dir!("tests/regression");
}
