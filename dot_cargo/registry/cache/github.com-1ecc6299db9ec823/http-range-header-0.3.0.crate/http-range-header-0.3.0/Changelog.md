# 0.1.0
Released first version under parse_range_headers

# 0.2.0
Rename to http-range-header

# 0.2.1
Make some optimization

# 0.2.2 
Fix a bug where single reversed range headers were erroneously passing validation

# 0.3.0 
Only expose a single error-type to make usage more ergonomic
