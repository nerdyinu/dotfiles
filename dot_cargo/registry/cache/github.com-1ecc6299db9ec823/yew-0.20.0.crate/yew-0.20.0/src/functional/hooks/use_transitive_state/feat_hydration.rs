//! The hydration variant.
//!
//! This is the same as the use_prepared_state.

#[doc(hidden)]
pub use crate::functional::hooks::use_prepared_state::feat_hydration::use_prepared_state as use_transitive_state;
