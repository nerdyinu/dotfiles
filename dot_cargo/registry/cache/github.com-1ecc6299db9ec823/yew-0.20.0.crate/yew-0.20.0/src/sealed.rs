/// Base traits for sealed traits.
pub trait Sealed {}
