# Contributing

See the ["Contributing" section of the `wasm-bindgen`
guide](https://rustwasm.github.io/docs/wasm-bindgen/contributing/index.html).
