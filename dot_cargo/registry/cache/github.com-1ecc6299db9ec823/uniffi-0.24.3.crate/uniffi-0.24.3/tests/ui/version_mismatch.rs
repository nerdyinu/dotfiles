// This should fail with a version mismatch.
uniffi::assert_compatible_version!("0.0.1"); // An error message would go here.

fn main() {}
