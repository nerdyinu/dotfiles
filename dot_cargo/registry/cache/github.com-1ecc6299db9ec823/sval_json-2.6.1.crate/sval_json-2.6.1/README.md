# `sval_json`

[![Rust](https://github.com/sval-rs/sval/workflows/json/badge.svg)](https://github.com/sval-rs/sval/actions)
[![Latest version](https://img.shields.io/crates/v/sval.svg)](https://crates.io/crates/sval_json)
[![Documentation Latest](https://docs.rs/sval_json/badge.svg)](https://docs.rs/sval_json)

JSON formatting for implementations of `sval::Value`.
