use cornucopia::run;
use miette::Result;

fn main() -> Result<()> {
    Ok(run()?)
}
