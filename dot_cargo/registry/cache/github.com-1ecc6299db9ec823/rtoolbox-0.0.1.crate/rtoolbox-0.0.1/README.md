# Rustastic Toolbox

`rtoolbox` contains utility functions I use in other projects. There are no backwards compatibility guarantees at all.

## License

The source code is released under the Apache 2.0 license.
