var N = null;var sourcesIndex = {};
sourcesIndex["deltae"] = {"name":"","files":["color.rs","convert.rs","delta.rs","eq.rs","lib.rs","round.rs","validate.rs"]};
createSourceSidebar();
