#![no_implicit_prelude]

#[::yew::prelude::hook]
fn use_boxed_fn(_f: ::std::boxed::Box<dyn::std::ops::Fn(&str) -> &str>) {
    ::std::todo!()
}

fn main() {}
