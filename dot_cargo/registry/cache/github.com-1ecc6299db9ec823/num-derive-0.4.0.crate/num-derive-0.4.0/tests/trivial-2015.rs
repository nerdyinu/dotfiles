// Same source, just compiled for 2015 edition
include!("trivial.rs");
