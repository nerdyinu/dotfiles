# Tauri Plugin {{ plugin_name_original }}
