export declare function execute(): Promise<void>
