---
"tauri-plugin-{{ plugin_name }}": "minor"
---

Initial release.
