---
"tauri-plugin-{{ plugin_name }}": "minor"
"tauri-plugin-{{ plugin_name }}-api": "minor"
---

Initial release.
