# phf_shared

This crate is for the `phf` crate, [find it on crates.io][phf] for details.

[phf]: https://crates.io/crates/phf
