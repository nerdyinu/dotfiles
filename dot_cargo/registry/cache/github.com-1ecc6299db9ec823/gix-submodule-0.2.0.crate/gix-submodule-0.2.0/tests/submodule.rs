use gix_testtools::Result;

mod file;
