# Themes

It contains examples showing how to write a theme.

If you would like to add a theme to zellij, please refer [zellij-utils/assets/themes](../../zellij-utils/assets/themes).
