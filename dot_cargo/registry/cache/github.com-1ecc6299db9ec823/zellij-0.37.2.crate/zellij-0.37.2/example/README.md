# Special considerations when using the configuration:

While trying to bind the newline character in the Config, use double quotes:

`Ctrl: "\n"` instead of `Ctrl: '\n'`
