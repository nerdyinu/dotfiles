# `is_ci` Release Changelog

<a name="1.1.1"></a>
## 1.1.1 (2021-09-22)

### Bug Fixes

* **now:** fix typo in bitbucket check ([d89ed22f](https://github.com/zkat/is_ci/commit/d89ed22fa489ef4fb8fda5eaf54e26610900b4e1))

<a name="1.1.0"></a>
## 1.1.0 (2021-09-22)

### Features

* **api:** Add cache/uncached APIs and deprecate is_ci ([adc5ec15](https://github.com/zkat/is_ci/commit/adc5ec152503f9ef6157f487fd7fc4ea251b4ff6))

<a name="1.0.0"></a>
## 1.0.0 (2021-09-22)

### Features

* **api:** Add initial API ([301f0a9b](https://github.com/zkat/is_ci/commit/301f0a9ba418da349140e93f2c031f2fd83c9a8a))

