//! Import prelude for Abscissa tests

pub use super::{
    process::{ExitStatus, OutputStream, Process, Stderr, Stdout},
    runner::CmdRunner,
};
