pub static RGB_UNIT_MAX: f64 = 255.0;
pub static HUE_MAX: f64 = 360.0;
pub static PERCENT_MAX: f64 = 100.0;
pub static RATIO_MAX: f64 = 1.0;
pub static ALL_MIN: f64 = 0.0;
