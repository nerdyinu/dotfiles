An internal helper crate for [enumset](https://github.com/Lymia/enumset). Not public API.
